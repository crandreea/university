//
// Created by Estera on 11.03.2024.
//
#include "MyList.h"
#include "cheltuiala.h"
#define CAP 6

#include <stdlib.h>

MyList *createEmpty(DestroyFunction f) {
    MyList *lista = (MyList *) malloc(sizeof(MyList));
    lista->elems = (ElemType *) malloc(sizeof(ElemType) * CAP);
    lista->lg = 0;
    lista->capacitate = CAP;
    lista->dfnc = f;
    return lista;
}

MyList* copyList(MyList* v, CopyFct copyFct) {
    MyList* v_copy = createEmpty(v->dfnc);
    for (int i = 0; i < v->lg; i++) {
        ElemType el = getElem(v, i);
        adauga(v_copy, copyFct(el));
    }
    return v_copy;
}

int size(MyList *l) {
    return l->lg;
}

void destroyLista(MyList* l){
    for (int i = 0; i < l->lg; i++)
    {
        l->dfnc(l->elems[i]);
    }
    l->lg = 0;
    free(l->elems);
    free(l);
}

void resize(MyList *l) {
    if (l->lg < l->capacitate)
        return;
    ElemType *new_elements = (ElemType *) malloc(sizeof(ElemType) * (2 * l->capacitate));
    for (int i = 0; i < l->lg; i++)
        new_elements[i] = l->elems[i];
    free(l->elems);
    l->elems = new_elements;
    l->capacitate = 2 * l->capacitate;
}

void adauga(MyList *lista, ElemType e) {
    resize(lista);
    lista->elems[lista->lg++] = e;
}


ElemType getElem(MyList *l, int poz) {
    return l->elems[poz];
}

void modifica(MyList *l,int poz,  ElemType e) {
    destroyCheltuiala(l->elems[poz]);
    l->elems[poz] = e;

}

ElemType sterge(MyList* l, int poz){
    ElemType el = l->elems[poz];
    for (int j = poz; j < l->lg - 1; j++)
        l->elems[j] = l->elems[j + 1];
    l->lg--;
    return el;
}

ElemType setElem(MyList* v, int poz, ElemType el) {
    ElemType replaced = v->elems[poz];
    v->elems[poz] = el;
    return replaced;
}

void sort(MyList* v, CompareFct cmpF) {
    int i, j;
    for (i = 0; i < size(v); i++) {
        for (j = i + 1; j < size(v); j++) {
            void* p1 = getElem(v, i);
            void* p2 = getElem(v, j);
            if (cmpF(p1, p2) > 0) {
                //interschimbam
                setElem(v, i, p2);
                setElem(v, j, p1);
            }
        }
    }
}