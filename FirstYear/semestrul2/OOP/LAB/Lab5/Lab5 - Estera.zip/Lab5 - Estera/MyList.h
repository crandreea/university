#pragma once

#include "cheltuiala.h"

typedef void* ElemType;
typedef void (*DestroyFunction)(ElemType);
typedef ElemType(*CopyFct)(ElemType);
//typedef Cheltuiala *ElemType;

typedef int (*CompareFct)(void* el1, void* el2);

typedef struct {
    ElemType *elems;
    int lg;
    int capacitate;
    DestroyFunction dfnc;
} MyList;

MyList *createEmpty(DestroyFunction f);

MyList* copyList(MyList* v, CopyFct copyFct);

void destroyLista(MyList* l);

void adauga(MyList *, ElemType e);

void modifica(MyList *, int poz, ElemType e);

ElemType sterge(MyList* l, int poz);

int size(MyList *);

ElemType getElem(MyList *l, int poz);

ElemType setElem(MyList* v, int poz, ElemType el);

void sort(MyList* v, CompareFct cmpF);