#include "cheltuiala.h"

#include <string.h>
#include <stdlib.h>
#include <ctype.h>

/*
 * creeaza o noua cheltuiala
 */
Cheltuiala *createCheltuiala(int id, int zi, float suma, char *tip) {
    Cheltuiala *rez = (Cheltuiala *) malloc(sizeof(Cheltuiala));
    rez->id = id;
    rez->zi = zi;
    rez->suma = suma;
    rez->tip = (char *) malloc(sizeof(char) * (strlen(tip) + 1));
    strcpy(rez->tip, tip);
    return rez;
}

void destroyCheltuiala(Cheltuiala *c) {
    c->id = -1;
    c->zi = -1;
    c->suma = -1;
    free(c->tip);
    free(c);
}

Cheltuiala *copyCheltuiala(Cheltuiala* c){
    return createCheltuiala(c->id, c->zi, c->suma, c->tip);
}

int containsOnlyLetters(const char *str) {
    while (*str) {
        if (!isalpha(*str)) {
            return 0; // Not a letter
        }
        str++;
    }
    return 1; // Only contains letters
}

int valideaza(Cheltuiala *c) {
    if (c->zi < 1 || c->zi > 31) {
        return 1;
    }
    if (c->suma < 0) {
        return 2;
    }
    if (strlen(c->tip) == 0 || containsOnlyLetters(c->tip)==0) { //adaugat
        return 3;
    }
    return 0;
}
