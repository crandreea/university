//
// Created by Croitoru Andreea on 22.03.2024.
//

#ifndef UNTITLED12_TESTS_H
#define UNTITLED12_TESTS_H
void testCreateDestroy();

void testValideaza();

void testCreateEmpty();

void testAdauga();

void testModifica();

void testSterge();

void testSize();

void testModificaCheltuiala();

void testAddCheltuiala();

void testStergeCheltuiala();

void testFilterBySum();

void testFilterBySumMax();

void testFilterByDay();

void testFilterByType();

void testSortareCrescatoare();

void testSortareDescrescatoare();

void testCopy();

void testContainsOnlyLetter();

void testUndo();

#endif //UNTITLED12_TESTS_H
