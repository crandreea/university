//
// Created by Estera on 10.03.2024.
//
#pragma once

typedef struct {
    int id;
    int zi;
    float suma;
    char *tip;
} Cheltuiala;

/*
 * Creeaza o noua cheltuiala
 */

Cheltuiala *createCheltuiala(int id, int zi, float suma, char *tip);

Cheltuiala *copyCheltuiala(Cheltuiala* c);

void destroyCheltuiala(Cheltuiala *c);

int valideaza(Cheltuiala *);

int containsOnlyLetters(const char *str); //adaugat



