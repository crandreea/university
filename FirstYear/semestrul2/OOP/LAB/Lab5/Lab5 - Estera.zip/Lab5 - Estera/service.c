#include <string.h>
#include "service.h"

ManagerCheltuieli createManagerCheltuieli()
{
    ManagerCheltuieli buget;
    buget.allCheltuieli = createEmpty((DestroyFunction )destroyCheltuiala);
    buget.undoList = createEmpty((DestroyFunction ) destroyLista);
    return buget;
}

void destroyManagerCheltuieli(ManagerCheltuieli* buget) {
    destroyLista(buget->allCheltuieli);
    destroyLista(buget->undoList);
}

int addCheltuiala(ManagerCheltuieli* buget, int id, int zi, float suma, char *tip) {
    Cheltuiala *c = createCheltuiala(id, zi, suma, tip);
    int valid = valideaza(c);
    if (valid != 0) {
        destroyCheltuiala(c);
        return valid;
    }
    for(int i = 0; i< size(buget->allCheltuieli); i++) {
        Cheltuiala *el = getElem(buget->allCheltuieli, i);
        if(el->id == id) {
            destroyCheltuiala(c);
            return 4;
         }
    }
    MyList* toUndo = copyList(buget->allCheltuieli, (CopyFct )copyCheltuiala);
    adauga(buget->allCheltuieli, c);
    adauga(buget->undoList, toUndo);

    return 0;
}

int modificaCheltuiala(ManagerCheltuieli* buget, int id, int zi, float suma, char *tip){
    Cheltuiala *new_c = createCheltuiala(id, zi, suma, tip);
    int valid = valideaza(new_c);
    if(valid!=0){
        destroyCheltuiala(new_c);
        return valid;
    }

    for(int pos = 0; pos < size(buget->allCheltuieli); pos ++){
        Cheltuiala *c = getElem(buget->allCheltuieli, pos);
        if(c->id == id)
        {
            MyList* toUndo = copyList(buget->allCheltuieli, (CopyFct )copyCheltuiala);
            adauga(buget->undoList, toUndo);

            modifica(buget->allCheltuieli,pos, new_c);
            return 0;
        }

    }

    destroyCheltuiala(new_c);
    return 1;

}


int stergeCheltuiala(ManagerCheltuieli* buget, int id) {
    for (int pos = 0; pos < size(buget->allCheltuieli); pos++) {
        Cheltuiala *c = getElem(buget->allCheltuieli, pos);
        if (c->id == id) {
            MyList* toUndo = copyList(buget->allCheltuieli, (CopyFct )copyCheltuiala);
            adauga(buget->undoList, toUndo);

            destroyCheltuiala(c);
            sterge(buget->allCheltuieli, pos);
            return 0;
        }
    }
    return 1;
}



MyList *filter_by_sum(ManagerCheltuieli* buget, float s) {
    MyList *filtered = createEmpty((DestroyFunction )destroyCheltuiala);
    for (int i = 0; i < buget->allCheltuieli->lg; i++) {
        Cheltuiala *c = getElem(buget->allCheltuieli, i);
        if (c->suma == s) {
            adauga(filtered, createCheltuiala(c->id,c->zi, c->suma, c->tip));
        }
    }
    return filtered;
}

MyList *filter_by_sum_max(ManagerCheltuieli* buget, float s) {
    MyList *filtered = createEmpty((DestroyFunction )destroyCheltuiala);
    for (int i = 0; i < buget->allCheltuieli->lg; i++) {
        Cheltuiala *c = getElem(buget->allCheltuieli, i);
        if (c->suma > s) {
            adauga(filtered, createCheltuiala(c->id,c->zi, c->suma, c->tip));
        }
    }
    return filtered;
}

MyList *filter_by_day(ManagerCheltuieli* buget, int d) {
    MyList *filtered = createEmpty((DestroyFunction )destroyCheltuiala);
    for (int i = 0; i < buget->allCheltuieli->lg; i++) {
        Cheltuiala *c = getElem(buget->allCheltuieli, i);
        if (c->zi == d) {
            adauga(filtered, createCheltuiala(c->id,c->zi, c->suma, c->tip));
        }
    }
    return filtered;
}

MyList *filter_by_type(ManagerCheltuieli* buget, char *tip) {
    MyList *filtered = createEmpty((DestroyFunction )destroyCheltuiala);
    for (int i = 0; i < buget->allCheltuieli->lg; i++) {
        Cheltuiala *c = getElem(buget->allCheltuieli, i);
        if (strcmp(c->tip, tip) == 0) {
            adauga(filtered, createCheltuiala(c->id,c->zi, c->suma, c->tip));
        }
    }
    return filtered;
}

int cmpcresc(Cheltuiala* c1, Cheltuiala* c2){
    if (c1->suma > c2->suma) return 1;
    return 0;
}

MyList *sortare_crescatoare(ManagerCheltuieli* buget) {
    MyList *lista = copyList(buget->allCheltuieli, (CopyFct )copyCheltuiala);
    sort(lista, (CompareFct )cmpcresc);
    return lista;
}

int cmpdescresc(Cheltuiala* c1, Cheltuiala* c2){
    if (c1->suma < c2->suma) return 1;
    return 0;
}

MyList *sortare_descrescatoare(ManagerCheltuieli* buget) {
    MyList *lista = copyList(buget->allCheltuieli, (CopyFct )copyCheltuiala);
    sort(lista, (CompareFct )cmpdescresc);
    return lista;
}

int undo(ManagerCheltuieli * buget) {
    if (size(buget->undoList) == 0)
        //nothing to undo
        return 0;
    MyList * l = sterge(buget->undoList, buget->undoList->lg - 1);
    destroyLista(buget->allCheltuieli);
    buget->allCheltuieli = l;
    return 1;
}

