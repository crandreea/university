//
// Created by Croitoru Andreea on 22.03.2024.
//
///
#include "cheltuiala.h"
#include "MyList.h"
#include "service.h"

#include <assert.h>
#include <string.h>

void testContainsOnlyLetter(){
    assert(containsOnlyLetters("5")==0);
    assert(containsOnlyLetters("sef")==1);
}
void testCreateDestroy() {
    Cheltuiala *c = createCheltuiala(1, 1, 100, "factura");
    assert(c->id == 1);
    assert(c->zi == 1);
    assert(c->suma == 100.0);
    assert(strcmp(c->tip, "factura") == 0);
    destroyCheltuiala(c);
}

void testValideaza() {
    Cheltuiala *c = createCheltuiala(1, 32, 100, "factura");
    assert(valideaza(c) == 1);
    destroyCheltuiala(c);
    c = createCheltuiala(1, 30, -20, "factura");
    assert(valideaza(c) == 2);
    destroyCheltuiala(c);
    c = createCheltuiala(1, 30, 20, "");
    assert(valideaza(c) == 3);
    destroyCheltuiala(c);
    c = createCheltuiala(1, 30, 20, "ajkd");
    assert(valideaza(c) == 0);
    destroyCheltuiala(c);
}

void testCreateEmpty() {
    MyList *lista_test = createEmpty((DestroyFunction )destroyCheltuiala);
    assert(size(lista_test) == 0);
    destroyLista(lista_test);
}

void testAdauga() {
    MyList *lista_test = createEmpty((DestroyFunction )destroyCheltuiala);
    adauga(lista_test, createCheltuiala(1, 13, 100, "facturi"));
    adauga(lista_test, createCheltuiala(2, 3, 10, "facturi"));
    adauga(lista_test, createCheltuiala(3, 3, 10, "facturi"));
    adauga(lista_test, createCheltuiala(4, 6, 0, "facturi"));
    adauga(lista_test, createCheltuiala(5, 3, 104, "facturi"));
    adauga(lista_test, createCheltuiala(6, 2, 130, "facturi"));
    adauga(lista_test, createCheltuiala(7, 3, 10, "facturi"));
    assert(size(lista_test) == 7);
    destroyLista(lista_test);
}

void testModifica() {
    MyList *lista_test = createEmpty((DestroyFunction )destroyCheltuiala);
    adauga(lista_test, createCheltuiala(1, 13, 100, "facturi"));
    modifica(lista_test, 0, createCheltuiala(1, 15, 192, "ejdlskd"));
    Cheltuiala *e = lista_test->elems[0];
    assert(e->zi == 15);
    assert(e->suma == 192);
    destroyLista(lista_test);
}

void testSterge() {
    MyList *lista_test = createEmpty((DestroyFunction )destroyCheltuiala);
    Cheltuiala *c = createCheltuiala(1, 13, 100, "facturi");
    adauga(lista_test, c);
    destroyCheltuiala(c);
    adauga(lista_test, createCheltuiala(2, 15, 192, "ejdlskd"));
    sterge(lista_test, 0);
    assert(size(lista_test)==1);
    destroyLista(lista_test);
}


void testSize() {
    MyList *lista_test = createEmpty((DestroyFunction )destroyCheltuiala);
    adauga(lista_test, createCheltuiala(1, 13, 100, "facturi"));
    adauga(lista_test, createCheltuiala(2, 15, 192, "ejdlskd"));
    assert(size(lista_test) == 2);
    destroyLista(lista_test);
}


void testAddCheltuiala() {
    ManagerCheltuieli buget = createManagerCheltuieli();
    addCheltuiala(&buget, 1, 13, 100, "facturi");
    //assert(size(lista_test) == 1);
    int error = addCheltuiala(&buget, 1, 2, 3, "f");
    assert(error == 4);
    error = addCheltuiala(&buget, 1, 2, 3, "3");
    assert(error == 3);
    destroyManagerCheltuieli(&buget);
}

void testModificaCheltuiala() {
    ManagerCheltuieli buget = createManagerCheltuieli();
    addCheltuiala(&buget, 1, 13, 100, "facturi");
    addCheltuiala(&buget, 2, 3, 10, "facturi");
    addCheltuiala(&buget, 3, 1, 1030, "facturi");
    int error = modificaCheltuiala(&buget, 1, 14, 900, "ceva");
    assert(error == 0);
    error = modificaCheltuiala(&buget, 1, 14, 900, "4");
    assert(error != 0);
    error = modificaCheltuiala(&buget, 5, 14, 900, "ceva");
    assert(error == 1);
    destroyManagerCheltuieli(&buget);
}

void testStergeCheltuiala() {
    ManagerCheltuieli buget = createManagerCheltuieli();
    addCheltuiala(&buget, 1, 13, 100, "facturi");
    stergeCheltuiala(&buget, 1);
    assert(buget.allCheltuieli->lg == 0);
    int error = stergeCheltuiala(&buget, 2);
    assert(error == 1);
    destroyManagerCheltuieli(&buget);
}

void testFilterBySum() {
    ManagerCheltuieli buget = createManagerCheltuieli();
    addCheltuiala(&buget, 1, 13, 100, "facturi");
    addCheltuiala(&buget, 2, 14, 100, "facturi");
    addCheltuiala(&buget, 3, 13, 400, "facturi");
    MyList *lista = filter_by_sum(&buget, 100);
    assert(lista->lg == 2);
    Cheltuiala *c = getElem(lista, 0);
    assert(c->suma == 100);
    destroyLista(lista);
    destroyManagerCheltuieli(&buget);
}

void testFilterBySumMax() {
    ManagerCheltuieli buget = createManagerCheltuieli();
    addCheltuiala(&buget, 1, 13, 100, "facturi");
    addCheltuiala(&buget, 2, 14, 100, "facturi");
    addCheltuiala(&buget, 3, 13, 400, "facturi");
    MyList *lista = filter_by_sum_max(&buget, 100);
    assert(lista->lg == 1);
    Cheltuiala *c = getElem(lista, 0);
    assert(c->suma == 400);
    destroyLista(lista);
    destroyManagerCheltuieli(&buget);
}

void testFilterByDay() {
    ManagerCheltuieli buget = createManagerCheltuieli();
    addCheltuiala(&buget, 1, 13, 100, "facturi");
    addCheltuiala(&buget, 2, 14, 100, "facturi");
    addCheltuiala(&buget, 3, 13, 400, "facturi");
    MyList *lista = filter_by_day(&buget, 13);
    assert(lista->lg == 2);
    Cheltuiala *c = getElem(lista, 0);
    assert(c->zi == 13);
    destroyLista(lista);
    destroyManagerCheltuieli(&buget);
}

void testFilterByType() {
    ManagerCheltuieli buget = createManagerCheltuieli();
    addCheltuiala(&buget, 1, 13, 100, "facturi");
    addCheltuiala(&buget, 2, 14, 100, "ceva");
    addCheltuiala(&buget, 3, 13, 400, "facturi");
    MyList *lista = filter_by_type(&buget, "facturi");
    assert(lista->lg == 2);
    Cheltuiala *c = getElem(lista, 0);
    assert(strcmp(c->tip, "facturi") == 0);
    destroyLista(lista);
    destroyManagerCheltuieli(&buget);
}


void testSortareCrescatoare() {
    ManagerCheltuieli buget = createManagerCheltuieli();
    addCheltuiala(&buget, 1, 13, 100, "facturi");
    addCheltuiala(&buget, 2, 14, 50, "ceva");
    addCheltuiala(&buget, 3, 13, 400, "facturi");
    MyList *lista = sortare_crescatoare(&buget);
    Cheltuiala *c = getElem(lista, 0);
    assert(c->suma == 50);
    destroyLista(lista);
    destroyManagerCheltuieli(&buget);
}

void testSortareDescrescatoare() {
    ManagerCheltuieli buget = createManagerCheltuieli();
    addCheltuiala(&buget, 1, 13, 100, "facturi");
    addCheltuiala(&buget, 2, 14, 50, "ceva");
    addCheltuiala(&buget, 3, 13, 400, "facturi");
    MyList *lista = sortare_descrescatoare(&buget);
    Cheltuiala *c = getElem(lista, 0);
    assert(c->id == 3);
    destroyLista(lista);
    destroyManagerCheltuieli(&buget);
}

void testCopy() {
    ManagerCheltuieli buget = createManagerCheltuieli();
    addCheltuiala(&buget, 1, 13, 100, "facturi");
    addCheltuiala(&buget, 2, 14, 50, "ceva");
    addCheltuiala(&buget, 3, 13, 400, "facturi");
    MyList *lista = copyList(buget.allCheltuieli, (CopyFct )copyCheltuiala);
    assert(lista->lg == 3);
    destroyLista(lista);
    destroyManagerCheltuieli(&buget);
}

void testUndo() {
    ManagerCheltuieli buget = createManagerCheltuieli();
    assert(addCheltuiala(&buget,1, 2, 3, "r")==0);
    assert(modificaCheltuiala(&buget, 1, 2, 3, "r") == 0);
    assert(stergeCheltuiala(&buget, 1) == 0);

    assert(size(buget.undoList)==3);
    //undo delete
    undo(&buget);
    assert(size(buget.undoList)==2);

    //undo modify
    undo(&buget);
    assert(size(buget.undoList)==1);


    //undo add
    undo(&buget);
    assert(size(buget.undoList)==0);

    int moreUndo = undo(&buget);
    assert(moreUndo == 0);
    destroyManagerCheltuieli(&buget);

}
