#include <stdio.h>
#include "cheltuiala.h"
#include "MyList.h"
#include "service.h"
#include "tests.h"


void Test() {
    testCreateDestroy();
    testCreateEmpty();
    testAdauga();
    testAddCheltuiala();
    testModifica();
    testValideaza();
    testModificaCheltuiala();
    testSterge();
    testStergeCheltuiala();
    testFilterBySum();
    testFilterBySumMax();
    testFilterByDay();
    testFilterByType();
    testSortareCrescatoare();
    testSortareDescrescatoare();
    testCopy();
    testSize();
    testContainsOnlyLetter();
    testUndo();
}

Cheltuiala *citesteCheltuiala() {
    printf("Id:");
    int id;
    scanf("%d", &id);

    printf("Ziua:");
    int zi;
    scanf("%d", &zi);

    printf("Suma:");
    float suma;
    scanf("%f", &suma);

    printf("Tip:");
    char tip[30];
    scanf("%s", tip);

    printf("\n");

    return createCheltuiala(id, zi, suma, tip);
}


Cheltuiala *citesteCheltuialaModificata() {
    printf("Id:");
    int id;
    scanf("%d", &id);

    printf("Noua zi:");
    int zi;
    scanf("%d", &zi);

    printf("Noua suma:");
    float suma;
    scanf("%f", &suma);

    printf("Noul tip:");
    char tip[30];
    scanf("%s", tip);

    printf("\n");

    return createCheltuiala(id, zi, suma, tip);
}

void display_list(MyList* l){
    if(size(l)==0)
    {
        printf("Nu exista cheltuieli...\n");
    }
    else{
        printf("Cheltuieli:\n");
        for (int i = 0; i < size(l); i++) {
            Cheltuiala * c = getElem(l, i);
            printf("Id %d, Zi %d, Suma %.3f, Tip %s\n", c->id, c->zi, c->suma,c->tip);
        }
    }
    printf("\n");
}


void run() {
    ManagerCheltuieli buget = createManagerCheltuieli();

    addCheltuiala(&buget, 1, 1, 200, "l");
    addCheltuiala(&buget, 2, 2, 100, "f");
    addCheltuiala(&buget, 3, 3, 300, "g");
    addCheltuiala(&buget, 4, 4, 150, "k");

    printf("1. Adauga\n");
    printf("2  Modificare\n");
    printf("3. Sterge cheltuiala dupa id\n");
    printf("4. Filtrare dupa suma\n");
    printf("5. Filtrare dupa zi\n");
    printf("6. Filtrare dupa tip\n");
    printf("7. Sortare crescatoare dupa suma\n");
    printf("8. Sortare descrescatoare dupa suma\n");
    printf("9. Afisare cheltuieli\n");
    printf("10. Undo\n");
    printf("0. Exit\n");
    printf("\n");

    int ok = 1;
    while (ok) {
        int cmd = 0;
        printf("Introduceti comanda: \n");
        scanf("%d", &cmd);
        switch (cmd) {
            case 1: {
                Cheltuiala *element = citesteCheltuiala();
                int error = addCheltuiala(&buget, element->id, element->zi, element->suma, element->tip);
                if(error !=0){
                    printf("Cheltuiala nu este valida...\n");
                }
                else{

                    printf("Cheltuiala a fost adaugata!\n");
                }
                destroyCheltuiala(element);

                printf("\n");
                break;
            }
            case 2: {
                Cheltuiala *element = citesteCheltuialaModificata();
                int error = modificaCheltuiala(&buget, element->id, element->zi, element->suma, element->tip);
                if(error != 0){
                    printf("Cheltuiala nu este valida...\n");
                }
                else{
                    printf("Modificarea a fost efectuata!\n");
                }
                destroyCheltuiala(element);
                printf("\n");
                break;
            }
            case 3: {
                printf("Id: ");
                int id;
                scanf("%d", &id);
                int error = stergeCheltuiala(&buget, id);
                if(error != 0){
                    printf("Cheltuiala cu acest id nu exista...\n");
                }
                else{
                    printf("Stergerea a fost realizata!\n");
                }
                printf("\n");
                break;
            }
            case 4: {
                printf("1.Suma egala\n2.Suma maxima\n0.Meniu principal\n");
                int sw = 1;
                while (sw){
                    int optiune = -1;
                    printf("Introduceti optiunea: \n");
                    scanf("%d", &optiune);
                    printf("Suma: ");
                    float suma;
                    scanf("%f", &suma);
                    if(optiune == 1){
                        MyList* lista_filtrata = filter_by_sum(&buget, suma);
                        display_list(lista_filtrata);
                        destroyLista(lista_filtrata);
                    }
                    else if(optiune == 2){
                        MyList* lista_filtrata = filter_by_sum_max(&buget, suma);
                        display_list(lista_filtrata);
                        destroyLista(lista_filtrata);
                    }
                    else if(optiune == 0){
                        sw = 0;

                    }
                    else{
                        printf("Optiunea invalida...\n");
                    }
                    printf("\n");
                }
                break;
            }
            case 5: {
                printf("Ziua: ");
                int ziua;
                scanf("%d", &ziua);
                MyList* lista_filtrata = filter_by_day(&buget, ziua);
                display_list(lista_filtrata);
                destroyLista(lista_filtrata);
                printf("\n");
                break;
            }
            case 6: {
                printf("Tipul: ");
                char tip[30];
                scanf("%s", tip);
                MyList* lista_filtrata = filter_by_type(&buget, tip);
                display_list(lista_filtrata);
                destroyLista(lista_filtrata);
                break;
            }
            case 7:{
                MyList* copie = sortare_crescatoare(&buget);
                display_list(copie);
                destroyLista(copie);
                break;
            }
            case 8:{
                MyList* copie = sortare_descrescatoare(&buget);
                display_list(copie);
                destroyLista(copie);
                break;
            }
            case 9:{
                display_list(buget.allCheltuieli);
                break;
            }
            case 10:{

                int successful = undo(&buget);
                if (successful)
                    printf("Undo realizat cu succes.\n");
                else
                    printf("Nu se mai poate face undo.\n");

            }
            case 0: {
                ok = 0;
                destroyManagerCheltuieli(&buget);
                break;
            }
            default:
                printf("Comanda invalida\n");
        }
    }
}

int main() {
    Test();
    run();
    return 0;
}

