#pragma once

#include "MyList.h"

typedef struct {
    MyList* allCheltuieli;
    MyList* undoList;
}ManagerCheltuieli;

ManagerCheltuieli createManagerCheltuieli();

void destroyManagerCheltuieli(ManagerCheltuieli * buget);

int addCheltuiala(ManagerCheltuieli * buget, int id, int zi, float suma, char *tip);


int modificaCheltuiala(ManagerCheltuieli * buget, int id, int zi, float suma, char *tip);

int stergeCheltuiala(ManagerCheltuieli * buget, int id);

MyList* filter_by_sum(ManagerCheltuieli * buget, float suma);

MyList *filter_by_sum_max(ManagerCheltuieli* buget, float s);

MyList* filter_by_day(ManagerCheltuieli * buget, int ziua);

MyList* filter_by_type(ManagerCheltuieli * buget, char* tip);

MyList* sortare_crescatoare(ManagerCheltuieli * buget);

MyList* sortare_descrescatoare(ManagerCheltuieli * buget);

int undo(ManagerCheltuieli * buget);



