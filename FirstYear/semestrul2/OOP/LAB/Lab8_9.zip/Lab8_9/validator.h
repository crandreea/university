#pragma once
#include <string>
using namespace std;

class Validator {
public:
    static void validateDisciplina(string name, int h, string type, string prof);
};