from domain.domain_student import *
class Student_Repository():
    def __init__(self) -> None:
        self._students = {'1': Student('1', 'Eric', '214')
                          ,'2': Student('2', 'John', '305')
                          ,'3': Student('3', 'Andreea', '212')
                          ,'4': Student('4', 'Alexandra', '216')}
        

    def get_all(self):
        return [self._students[identifier] for identifier in self._students.keys()]
    
    def get_student(self, identifier):
        return self._students[identifier]

    def __len__(self):
        return len(self._students)
    
    def add_student(self, student : Student):
        student_id = student.get_id()
        if student_id in self._students.keys():
                raise Exception(f"Studentul cu ID-ul {student_id} a fost introdus deja...")
        
        self._students[student_id] = student 
    
    def modify_student(self, new_student  : Student):
        student_id = new_student.get_id()
        if student_id not in self._students.keys():
            raise Exception(f"Studentul cu ID-ul {student_id} nu exista...")
        
        self._students[student_id] = new_student
        
    def delete_student(self, student_id) -> None:
        if student_id not in self._students.keys():
            raise Exception(f"Studentul cu ID-ul {student_id} nu exista...")
        self._students.pop(id)

    def search_student(self, student_id):
        
        if student_id not in self._students.keys():
            raise Exception(f"Studentul cu ID-ul {student_id} nu exista...")
        return self._students[student_id]
    
    
    
    
