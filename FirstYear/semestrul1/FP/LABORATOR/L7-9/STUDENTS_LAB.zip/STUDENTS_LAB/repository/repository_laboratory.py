from domain.domain_laboratory import *
class Laboratory_Repository:
    def __init__(self) -> None:
        self._problems = {'1': Laboratory('1', 'contest', '2023/11/24'),
                          '2': Laboratory('2', 'practice', '2023/11/25'),
                          '3': Laboratory('3', 'calculator', '2024/01/02')}

    def get_all(self):
        return [self._problems[identifier] for identifier in self._problems.keys()]

    def get_problem(self, identifier):
        return self._problems[identifier]
    
    def __len__(self):
        return len(self._problems)
    
    def add_problem(self, problem : Laboratory):
        problem_id = problem.get_id()
        if problem_id in self._problems.keys():
            raise Exception(f"Problema {problem_id} a fost introdusa deja...")
        self._problems[problem_id] = problem
    
    def modify_problem(self, new_problem : Laboratory):
        id = new_problem.get_id()
        if id not in self._problems.keys():
            raise Exception(f"Problema {id} nu exista...")
        self._problems[id] = new_problem

    def delete_problem(self, id):
        if id not in self._problems.keys():
            raise Exception(f"Problema {id} nu exista...")
        self._problems.pop(id)

    def search_problem(self, id):
        if id not in self._problems.keys():
            raise Exception(f"Problema {id} nu exista...")
        return self._problems[id]
        