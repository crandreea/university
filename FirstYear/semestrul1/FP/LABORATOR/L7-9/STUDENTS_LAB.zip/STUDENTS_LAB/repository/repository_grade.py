from domain.domain_grade import *
from user_interface.validation import *
class Grade_Repository(Validator):
    def __init__(self):
        self.__grades = [
            Grade(Student('1', 'Eric', '214'), '1', '9'),
            Grade(Student('1', 'Eric', '214'), '2', '8'),
            Grade(Student('2', 'John', '305'), '1', '6'),
            Grade(Student('2', 'John', '305'), '2', '7'),
            Grade(Student('3', 'Andreea', '212'), '1', '6')
        ]

    def find(self, student, problem):
        for grade in self.__grades:
            if grade.get_student() == student and grade.get_problem() == problem:
                return grade
        return None
  
    def get_all(self):
        return [self.__grades[identifier] for identifier in self.__grades]
    
    def add(self, grade: Grade):
        if self.find(grade.get_student(), grade.get_problem())!=None:
            raise Exception("Problema a fost deja notata!")
        
        if self.is_grade(grade.get_grade()) == False:
            raise Exception("Notare se realizeaza de la 1 la 10!")

        self.__grades.append(grade)

    def size(self):
        return len(self.__grades)
    
    def get_grades_for_student(self, student):
        rez = []
        for grade in self.__grades:
            if grade.get_student() == student:
                rez.append(grade)
        return rez
    
    def get_grade_for_student_by_problem(self, student, problem_id):
        st_grade = 0
        for grade in self.__grades:
            if grade.get_student() == student and grade.get_problem() == problem_id:
                st_grade = int(grade.get_grade())
        return st_grade
    
    def get_all_grades_for_student(self, student):
        grades = []
        for grade in self.__grades:
            if grade.get_student() == student:
                grades.append(int(grade.get_grade()))
        return grades

    

    