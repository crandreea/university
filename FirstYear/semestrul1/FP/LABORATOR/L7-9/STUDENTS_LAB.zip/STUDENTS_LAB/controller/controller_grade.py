from repository.repository_grade import *
from repository.repository_student import *

class Grade_Manager:
    def __init__(self, grade_repo : Grade_Repository, student_repo : Student_Repository):
        self.__grade_repo = grade_repo
        self.__student_repo = student_repo

    def assign(self, student_id, problem_id, grade):
        student = self.__student_repo.search_student(student_id)
        grade = Grade(student, problem_id, grade)

        self.__grade_repo.add(grade)

        return grade
    
    def list_grades_for_student(self, student_id):
        student = self.__student_repo.search_student(student_id)

        return self.__grade_repo.get_grades_for_student(student)
    

    def average_grade_for_student(self):
        students = self.__student_repo.get_all()
        averages = {}

        for student in students:
            grades = self.__grade_repo.get_all_grades_for_student(student)
            sum_grades = sum(grades)
            total_grades = len(grades)
            if total_grades > 0:
                averages[student.get_id()] = round(sum_grades / total_grades, 2)
        
        result = []

        for key, value in averages.items():
            student = self.__student_repo.get_student(key)
            student_name = student.get_name()
            student_average = value
            if student_average < 5:
                dto = StudentGradeDTO(student_name, student_average)
                result.append(dto)
        
        return result
    
    def students_grade_for_problem(self, problem_id):
        students = self.__student_repo.get_all()
        result = []

        for student in students:
            grade = self.__grade_repo.get_grade_for_student_by_problem(student, problem_id)
            student_name = student.get_name()
            if grade > 0:
                dto = StudentGradeDTO(student_name, grade)
                result.append(dto)

        studenti_ordonati = sorted(result, key=lambda x: (-x.get_grade(), x.get_name()))
        return studenti_ordonati

            

